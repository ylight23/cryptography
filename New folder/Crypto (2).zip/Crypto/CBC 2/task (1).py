from secret import FLAG
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from hashlib import md5
import json
import random
import os

class Cipher:
    def __init__(self,k1,k2,k3):
        self.k1 = md5(k1).digest()
        self.k2 = md5(k2).digest()
        self.k3 = md5(k3).digest()
    
    def encrypt(self,m):
        iv1 = os.urandom(16)
        iv2 = os.urandom(16)
        iv3 = os.urandom(16)
        cipher1 = AES.new(self.k1,AES.MODE_CBC,iv1)
        cipher2 = AES.new(self.k2,AES.MODE_CBC,iv2)
        cipher3 = AES.new(self.k3,AES.MODE_CBC,iv3)
        m = pad(m,16)
        return (iv1 + iv2 + iv3 + cipher3.encrypt(cipher2.encrypt(cipher1.encrypt(m)))).hex()

    def decrypt(self,c):
        iv1 = c[:16]
        iv2 = c[16:32]
        iv3 = c[32:48]
        c = c[48:]
        cipher1 = AES.new(self.k1,AES.MODE_CBC,iv1)
        cipher2 = AES.new(self.k2,AES.MODE_CBC,iv2)
        cipher3 = AES.new(self.k3,AES.MODE_CBC,iv3)
        return cipher1.decrypt(cipher2.decrypt(cipher3.decrypt(c))).hex()


if __name__ == "__main__":
    k1 = str(random.randrange(0,10**6)).encode()
    k2 = str(random.randrange(0,10**6)).encode()
    k3 = str(random.randrange(0,10**6)).encode()
    cipher = Cipher(k1,k2,k3)
    
    try:
        msg = input(">>> ")
        msg = json.loads(msg.strip())
        if msg["do"] == "encrypt":
            res = cipher.encrypt(bytes.fromhex(msg["m"]))
            print(res)

        elif msg["do"] == "decrypt":
            res = cipher.decrypt(bytes.fromhex(msg["c"]))
            print(res)
        
        print("The encrypted flag is",cipher.encrypt(FLAG))

    except:
        print('Usage: {"do": "encrypt", "m": "plaintext-in-hex"} or {"do": "decrypt", "c": "ciphertext-in-hex"}')
        quit()
