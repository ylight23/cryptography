from Crypto.Cipher import AES
from secret import FLAG
import base64
import string
import os

chars = string.ascii_letters + string.digits
key = os.urandom(16)

def generate_token(user, isAdmin=False):
    if all([i in chars for i in user]) and len(user) != 0:
        msg = f'username={user}|isAdmin={isAdmin}|'.encode()
        msg = msg + bytes(AES.block_size - (len(msg) % AES.block_size))
        cipher = AES.new(key, AES.MODE_CBC, bytes(AES.block_size))
        tag = cipher.encrypt(msg)[- AES.block_size:]
        token = msg + tag
        return base64.b64encode(token)
    return b''

def parse_msg(msg):
    msg = msg.split(b'|')
    data = {}
    for m in msg:
        try:
            key,value = m.split(b'=')
            data[key] = value
        except:
            continue
    return data

def check_token(token):
    msg = token[: - AES.block_size]
    cipher = AES.new(key, AES.MODE_CBC, bytes(AES.block_size))
    tag = cipher.encrypt(msg)[- AES.block_size:]
    if tag == token[- AES.block_size:]:
        return True
    else:
        return False

if __name__ == '__main__':
    admin_token = generate_token("foobar1337",True)
    banner = f"""Welcome everyone,
We will give you a flag if you have the Admin token. This means there's no flag for CTFer, sorry.
Warning: Last time, foobar1337 leaked his token "{admin_token.decode()}"
Fortunately, we have revoked that token, no one can use it anymore. So keep your token in a safe, please!
"""

    print(banner)
    try:
        username = input("[-] Enter your name to register (Skip if you have a token): ")
        print(generate_token(username).decode())
        token = input("[-] Token: ").strip().encode()
        assert admin_token not in token
        token = base64.b64decode(token)
        if check_token(token):
            data = parse_msg(token[: - AES.block_size])
            if eval(data[b"isAdmin"]) and data[b"username"] != b"foobar1337":
                print(FLAG)
            else:
                print(f"Hi {data[b'username'].decode()}, currently there's no flag for you. Please come back later...")
    except:
        quit()