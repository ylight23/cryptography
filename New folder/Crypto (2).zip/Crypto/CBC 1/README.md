Can you forge a valid token?

nc 139.180.134.15 50001