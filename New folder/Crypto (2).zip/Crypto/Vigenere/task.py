import os
import base64

def encrypt(a,b):
    return bytes([(x + y) % 256 for x,y in zip(a,b)])

key = os.urandom(8)
msg = open("message.txt","r").read()
assert msg.isprintable()

ciphertext = b""

for i in range(0,len(msg),8):
    m = msg[i:i+8]
    k = key[:len(m)]
    ciphertext += encrypt(m.encode(),k)

with open("output.txt","wb") as f:
    f.write(base64.b64encode(ciphertext))