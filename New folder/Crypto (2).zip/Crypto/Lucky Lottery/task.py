from fastecdsa import curve
import json
from random import randint
from secret import FLAG

class LuckyLottery:
    def __init__(self,E):
        self.E = E
        self.s = randint(1,E.q)
        self.P = randint(1,E.q) * E.G
        self.Q = self.E.b * self.P
    
    def __str__(self):
        return '\n'.join([str(self.E), str(self.P), str(self.Q)])

    def update_state(self):
        self.s = (self.P * self.s).x

    def randint(self):
        self.update_state()
        r = (self.Q * self.s).x
        return r % 2**245

if __name__ == "__main__":
    LL = LuckyLottery(curve.P256)
    print(LL)
    for i in range(10): # You have 10 times to test your luck
        r = LL.randint()
        numbers = []
        while r:
            numbers.append(r % 2**7)
            r = r >> 7
        try:
            user_input = input("Your numbers: ") # format: [number1, number2,...]
            user_input = json.loads(user_input.strip())
            correct = 0
            for a,b in zip(numbers,user_input):
                if a == b:
                    correct += 1
            if correct == len(numbers):
                print(f"Wow, you deserve a special reward. The flag is {FLAG}")
                quit()
            else:
                print(f"{numbers}\nYou won ${correct*100}")
        except:
            quit()