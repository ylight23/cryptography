from secret import FLAG
import random
assert FLAG.startswith(b"KCSC{")

def xor(a,b):
    return bytes([x^y for x,y in zip(a,b)])

def encrypt(msg,key):
    msg = msg + bytes(len(key) - (len(msg) % len(key)))
    msg = [msg[i:i+len(key)] for i in range(0,len(msg),len(key))]
    c = []
    for m in msg:
        c.append(xor(m,key))
        key = xor(m,key)
    random.shuffle(c)
    return b''.join(c).hex()

key = random.randbytes(5)
c = encrypt(FLAG,key)
print(c)

# cd8fa01b3db9a1f0374992ce930508d6e3d65f39a2bce73166e191a268789591af2f4da5f6dd1b3d