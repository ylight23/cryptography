A valid signature for a flag. Sounds like a fair deal to me :)) author: naul

nc 103.245.250.31 31850