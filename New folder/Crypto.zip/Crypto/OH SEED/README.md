Can you guess a random number?

author: ffyytt

nc 103.245.250.31 30620