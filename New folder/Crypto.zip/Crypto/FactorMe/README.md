Just a simple factor challenge with some hint :))
nc 103.245.250.31 30521